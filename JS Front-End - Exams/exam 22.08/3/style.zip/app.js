const BASE_URL = 'http://localhost:3030/jsonstore/appointments/';

const loadBtn = document.getElementById('load-appointments');
const appointmentsList = document.getElementById('appointments-list');
const addBtn = document.getElementById('add-appointment');
const editBtn = document.getElementById('edit-appointment');
const carModelInput = document.getElementById('car-model');
const carServiceSelect = document.getElementById('car-service');
const dateInput = document.getElementById('date');

let editAppointmentId = null;

loadBtn.addEventListener('click', loadAppointments);
addBtn.addEventListener('click', addAppointment);
editBtn.addEventListener('click', editAppointment);

async function loadAppointments() {
  try {
    const response = await fetch(BASE_URL);
    const data = await response.json();

    appointmentsList.innerHTML = '';

    Object.values(data).forEach((appointment) => {
      const appointmentItem = createAppointmentItem(appointment);
      appointmentsList.appendChild(appointmentItem);
    });
  } catch (error) {
    console.error('Failed to load appointments', error);
  }
}

function createAppointmentItem({ _id, model, service, date }) {
  const li = document.createElement('li');
  li.className = 'appointment';

  li.innerHTML = `
    <h2>${model}</h2>
    <h3>${date}</h3>
    <h3>${service}</h3>
    <div class="buttons-appointment">
      <button class="change-btn">Change</button>
      <button class="delete-btn">Delete</button>
    </div>
  `;

  const changeBtn = li.querySelector('.change-btn');
  const deleteBtn = li.querySelector('.delete-btn');

  changeBtn.addEventListener('click', () => populateFormForEdit(_id, model, service, date));
  deleteBtn.addEventListener('click', () => deleteAppointment(_id));

  return li;
}

function populateFormForEdit(id, model, service, date) {
  editAppointmentId = id;
  carModelInput.value = model;
  carServiceSelect.value = service;
  dateInput.value = date;

  addBtn.disabled = true;
  editBtn.disabled = false;
}

async function addAppointment() {
  const model = carModelInput.value.trim();
  const service = carServiceSelect.value;
  const date = dateInput.value;

  if (model && service && date) {
    const newAppointment = { model, service, date };

    try {
      await fetch(BASE_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newAppointment)
      });

      loadAppointments();
      clearForm();
    } catch (error) {
      console.error('Failed to add appointment', error);
    }
  }
}

async function editAppointment() {
  if (!editAppointmentId) return;

  const model = carModelInput.value.trim();
  const service = carServiceSelect.value;
  const date = dateInput.value;

  if (model && service && date) {
    const updatedAppointment = { model, service, date };

    try {
      await fetch(`${BASE_URL}${editAppointmentId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedAppointment)
      });

      loadAppointments();
      clearForm();
      editAppointmentId = null;

      addBtn.disabled = false;
      editBtn.disabled = true;
    } catch (error) {
      console.error('Failed to edit appointment', error);
    }
  }
}

async function deleteAppointment(id) {
  try {
    await fetch(`${BASE_URL}${id}`, {
      method: 'DELETE'
    });

    loadAppointments();
  } catch (error) {
    console.error('Failed to delete appointment', error);
  }
}

function clearForm() {
  carModelInput.value = '';
  carServiceSelect.value = '';
  dateInput.value = '';
}
